from PIL import Image
from pylab import *
im = array(Image.open("255.jpg").convert('L'))
for i in range(55,255,50):
    image = (i/255)*im
    out = Image.fromarray(uint8(image))
    out.save("C:\\Users\Administrator\Desktop\\实心实验\Inquisit\叶容杉_差别阈限2.0\\"+str(i)+".bmp")