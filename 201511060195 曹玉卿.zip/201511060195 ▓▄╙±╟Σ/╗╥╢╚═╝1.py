Python 3.5.2 (v3.5.2:4def2a2901a5, Jun 25 2016, 22:18:55) [MSC v.1900 64 bit (AMD64)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> 
===== RESTART: C:/Users/露露/AppData/Local/Programs/Python/Python35/灰度图.py =====
Traceback (most recent call last):
  File "C:/Users/露露/AppData/Local/Programs/Python/Python35/灰度图.py", line 6, in <module>
    im = array(Image.open("a01.jpg").convert("L"))
  File "C:\Users\露露\AppData\Local\Programs\Python\Python35\lib\site-packages\PIL\Image.py", line 2282, in open
    fp = builtins.open(filename, "rb")
FileNotFoundError: [Errno 2] No such file or directory: 'a01.jpg'
>>> 
