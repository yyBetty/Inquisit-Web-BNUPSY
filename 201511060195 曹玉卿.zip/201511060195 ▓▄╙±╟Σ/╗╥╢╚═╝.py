from PIL import Image
from pylab import *
# 设置当前工作路径
work_dir = "E:\Python"
# 读取 灰度 转数组
im = array(Image.open("a01.jpg").convert("L"))
# 设置循环生成图片
for i in range(0, 255, 17):
    image = (i / 255) * im
    out = Image.fromarray(uint8(image))
    out.save( work_dir+"N" + str(i) + ".bmp")
